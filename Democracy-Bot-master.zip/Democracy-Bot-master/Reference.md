Reference
=========


#### 디스코드 공식 개발자 정보 사이트
https://discordapp.com/developers/docs/intro

* * *
#### 파이썬을 이용한 디스코드 봇 개발 블로그 1
https://code-200.tistory.com/10

* * *
#### 파이썬을 이용한 디스코드 봇 개발 블로그 2
https://m.blog.naver.com/yulesdays/221106584532

* * *
#### 파이썬을 이용한 디스코드 봇 개발 깃헙
https://github.com/Rapptz/discord.py

* * *
#### 디스코드 봇 파이썬 API
https://discordpy.readthedocs.io/en/latest/api.html

* * *
#### 파이썬에서 이미지 생성 예제
http://mydevnote.tistory.com/117
